run 1 the do partition manually cause i don't know how to automate that
then do 2
then do 3 and finally set passwords manually cause again idk
and for the last step do umount -a && reboot
i could do 4 automate that but meh...
