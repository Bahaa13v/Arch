ln -sf /usr/share/zoneinfo/Africa/Algiers /etc/localtime

hwclock --systohc

cp /instmp/src/locale.gen /etc/

locale-gen

cp /instmp/src/vconsole.conf /etc/

cp /instmp/src/hostname /etc/

grub-install /dev/sda

grub-mkconfig -o /boot/grub/grub.cfg

systemctl enable NetworkManager

echo "type: passwd"

echo "then type the root password"
sleep 1
echo "type: passwd bahaa"

echo "then type your user password"
