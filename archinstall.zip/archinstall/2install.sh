mkfs.ext4 /dev/sda1

mkswap /dev/sda2

swapon /dev/sda2

mount /dev/sda1 /mnt

pacstrap -K /mnt base linux linux-firmware sudo networkmanager nano

genfstab -U /mnt >> /etc/fstab

mkdir -p /mnt/instpm

cp -r rsc /mnt/instmp/

cp -r 3configs.sh /mnt/instmp/

echo "type this : bash /instmp/3configs.sh"

arch-chroot /mnt
