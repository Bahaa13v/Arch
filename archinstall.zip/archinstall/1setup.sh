#!/bin/bash

setfont ter-v20b

loadkeys fr

iwctl --passphrase=45629514 station wlan0 connect "Idoom 4G_99661"

pacman-key --init

pacman-key --populate

pacman -Sy archlinux-keyring

echo "do this"

echo "fdisk /dev/sda"

echo "o"

echo "n"

echo "keep pressing Enter but when it promped Last Sector write -16G"

echo "n"

echo "keep pressing Enter"

echo "a"

echo "choose sda1"

echo "w"
